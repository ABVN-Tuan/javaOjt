sap.ui.define([],()=>{"use strict";return{isAdmin:function(i){return i==="admin"}}});
//# sourceMappingURL=formatter.js.map